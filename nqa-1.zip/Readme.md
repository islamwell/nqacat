Define variables
root of API
1. nqapp.nurulquran.com
latest 12/1/21
