const cracoServiceWrokerConfig = require("./cracoServiceWrokerConfig");

module.exports = {
    plugins: [{ plugin: cracoServiceWrokerConfig }],
};
